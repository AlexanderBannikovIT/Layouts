const modals = document.querySelectorAll('dialog')

modals.forEach(modal => {
  const modalBox = modal.querySelector('#modal-box')
  const showModalBtn = modal.nextElementSibling // Кнопка открывающая модальное окно следующий элемент после модального окна
  const closeModalBtn = modal.querySelector('#close-modal-btn')
  let isModalOpen = false

  showModalBtn.addEventListener('click', (e) => {
    modal.showModal()
    isModalOpen = true
    e.stopPropagation()
  })

  closeModalBtn.addEventListener('click', () => {
    modal.close()
    isModalOpen = false
  })

  document.addEventListener('click', (e) => {
    if (isModalOpen && !modalBox.contains(e.target) && e.target !== showModalBtn) {
      modal.close()
    }
  })
})



const splideLinks = document.querySelectorAll('.block-splide-link');

splideLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault(); // Отменяем стандартное действие перехода по ссылке

        // Создаем модальное окно с текстом "Покупка недоступна" и кнопкой "Закрыть"
        const modal = document.createElement('dialog');
        modal.innerHTML = `
            <p id="modal-text">Покупка недоступна</p>
            <button id="close-modal-btn">Закрыть</button>
        `;
        document.body.appendChild(modal);
        modal.showModal();

        // Обработчик события клика на кнопке "Закрыть"
        const closeModalBtn = modal.querySelector('#close-modal-btn');
        closeModalBtn.addEventListener('click', () => {
            modal.close();
        });

        // Стили для кнопки "Закрыть" (центрирование)
        closeModalBtn.style.position = 'absolute';
        closeModalBtn.style.left = '50%';
        closeModalBtn.style.transform = 'translateX(-50%)';
        closeModalBtn.style.bottom = '20px';

        // Стили для тега <p> (изменение размера шрифта)
        const modalText = modal.querySelector('#modal-text');
        modalText.style.fontSize = '24px';

        // Обработчик события клика на документе для закрытия модального окна при клике вне него
        const clickHandler = (event) => {
            if (!modal.contains(event.target)) {
                modal.close();
                document.removeEventListener('click', clickHandler);
            }
        };

        // Добавляем обработчик события клика на документ только после открытия модального окна
        setTimeout(() => {
            document.addEventListener('click', clickHandler);
        }, 0);
    });
});






const SplideOne = new Splide("#SplideOne")
SplideOne.mount()

const SplideTwo = new Splide("#SplideTwo")
SplideTwo.mount()



// Показываем кнопку "Наверх" после прокрутки страницы
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  var scrollToTopBtn = document.getElementById("scrollToTopBtn");
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    scrollToTopBtn.style.display = "block";
  } else {
    scrollToTopBtn.style.display = "none";
  }
}

// Прокручиваем страницу наверх при клике на кнопку
document.getElementById("scrollToTopBtn").addEventListener("click", function() {
  document.body.scrollTop = 0; // Для Safari
  document.documentElement.scrollTop = 0; // Для Chrome, Firefox, IE и Opera
});



